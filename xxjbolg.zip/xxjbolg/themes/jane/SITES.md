## Sites using Hugo-theme-Jane

- [Notes on Blue Skies](https://terrty.net) - Personal blog in Russian by @paskal
- [贤民的比特记忆](http://www.xianmin.org/) - A Chinese blog.
- [TeaTech](https://maiyang.me/) - Gopher @yangwenmai.
- [AxdLog](https://axdlog.com) - Personal blog in English and traditional Chinese by @MaxdSre
- [Time](https://ifttl.com/) - Personal Blog
- [IT & Laws](https://itlaws.cn/) - itLaws，一个律师的关于IT、法律的博客
- [赫赫文王](https://kqh.ac/) - 不务正业的历史系学生一个
- [Potioneer's Essays](https://william-yeh.net/) - Personal blog on software development in traditional Chinese by @William-Yeh
- [联盟少侠博客](https://shaoxia.xyz/) - 一个日记博客.Simple Blog, Simple Days。
