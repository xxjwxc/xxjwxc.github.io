hugo
cp -rf ~/xxjbolg/public/* ~/work/path/go/src/github.com/xie1xiao1jun/xie1xiao1jun.github.io/
cp -rf ~/xxjbolg/content/post ~/work/path/go/src/github.com/xie1xiao1jun/xie1xiao1jun.github.io/backup
echo "发布成功"

