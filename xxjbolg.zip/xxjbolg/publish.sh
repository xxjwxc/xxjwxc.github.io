hugo
cp -rf ~/xxjbolg/public/* ~/work/path/go/src/github.com/xxjwxc/xxjwxc.github.io/
cp -rf ~/xxjbolg/content/post ~/work/path/go/src/github.com/xxjwxc/xxjwxc.github.io/backup
echo "发布成功"

