---
title: "About"
date: 2019-05-01T00:00:00+08:00
lastmod: 2019-05-01T00:00:00+08:00
menu: "main"
weight: 50

# you can close something for this content if you open it in config.toml.
comment: false
mathjax: false
---

Contact to me:


![](https://hospital.xxjwxc.cn/postcardserver/file/qrcode/oUq8a0eTRg8qaCLf_AaYuIXS63wk.jpg)


Personal blog:

* [csdn](https://blog.csdn.net/xie1xiao1jun)
* [github](https://github.com/xxjwxc)
* [find me](https://hospital.xxjwxc.cn/postcardserver/file/qrcode/oUq8a0eTRg8qaCLf_AaYuIXS63wk.jpg)


Learn more and contribute on [GitHub](https://github.com/xxjwxc).

