---
title: "About"
date: 2017-08-20T21:38:52+08:00
lastmod: 2017-08-28T21:41:52+08:00
menu: "main"
weight: 50

# you can close something for this content if you open it in config.toml.
comment: false
mathjax: false
---

Contact to me:


![](https://hospital.xxjwxc.cn/postcardserver/file/qrcode/oUq8a0eTRg8qaCLf_AaYuIXS63wk.jpg)


Personal blog:

* [csdn](https://blog.csdn.net/xie1xiao1jun)
* [github](https://github.com/xie1xiao1jun)
* [find me](https://hospital.xxjwxc.cn/postcardserver/file/qrcode/oUq8a0eTRg8qaCLf_AaYuIXS63wk.jpg)


Learn more and contribute on [GitHub](https://github.com/xie1xiao1jun).

